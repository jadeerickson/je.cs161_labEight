# cs161_wk8_labTemplate
 Compile command: javac -d bin -sourcepath src -cp "bin;lib" src/main/java/Main.java
 
 Run Command: java -cp "bin;lib/mssql-jdbc.13.jar" main.java.Main